<?php
session_start();
define ('FPAG',10); // Número de filas por página


require_once 'app/helpers/util.php';
require_once 'app/helpers/fpdf.php';
require_once 'app/config/configDB.php';
require_once 'app/models/Cliente.php';
require_once 'app/models/AccesoDatosPDO.php';
require_once 'app/controllers/crudclientes.php';



/* //EJERCICIO 8 - login correcto
if (!isset($_SESSION['login'])){
    header('Location: acceso.php');
}elseif(isset($_SESSION['login'])){
    $stmt_login = $this->dbh->prepare('SELECT * FROM user WHERE login = ? AND password = ?');
    $stmt_login->bindParam(1,$login);
    $stmt_login->bindParam(2,$password);
    $stmt_login->execute();

    $resu = $stmt_login->fetch(PDO::FETCH_OBJ);
    print_r($datos);
}else{
    echo "Error";
} */


//---- PAGINACIÓN ----
$midb = AccesoDatos::getModelo();
$totalfilas = $midb->numClientes();                 //obtiene las filas totales de la base de datos.
if ( $totalfilas % FPAG == 0){
    $posfin = $totalfilas - FPAG;                   //990
} else {
    $posfin = $totalfilas - $totalfilas % FPAG;     //1059 - 9 
}

if ( !isset($_SESSION['posini']) ){
  $_SESSION['posini'] = 0;                          //numero de registros de la sesion
}
$posAux = $_SESSION['posini'];
//------------



ob_start(); // La salida se guarda en el bufer
if ($_SERVER['REQUEST_METHOD'] == "GET" ){
    
    // Proceso las ordenes de navegación
    if ( isset($_GET['nav'])) {
        switch ( $_GET['nav']) {
            case "Primero"  : $posAux = 0; break;
            case "Siguiente": $posAux +=FPAG; if ($posAux > $posfin) $posAux=$posfin; break;
            case "Anterior" : $posAux -=FPAG; if ($posAux < 0) $posAux =0; break;
            case "Ultimo"   : $posAux = $posfin;
        }
        $_SESSION['posini'] = $posAux;
    }


     // Proceso las ordenes de navegación en detalles
    if ( isset($_GET['nav-detalles']) && isset($_GET['id']) ) {
        switch ( $_GET['nav-detalles']) {
            case "Siguiente": crudDetallesSiguiente($_GET['id']); break;
            case "Anterior" : crudDetallesAnterior($_GET['id']); break;   
        }
    }


     // Proceso las ordenes de navegación en modificar
    if ( isset($_GET['nav-modificar']) && isset($_GET['id']) ) {
        switch ( $_GET['nav-modificar']) {
            case "Siguiente": crudModificarSiguiente($_GET['id']); break;
            case "Anterior" : crudModificarAnterior($_GET['id']); break;
        }
    }


    //ordenar por campos
        //sesion de estado de ordenación
        
        if (!isset($_SESSION['s_orden'])){
            $s_orden = $_SESSION['s_orden'] = 'DESC';
        }else{
            $s_orden = $_SESSION['s_orden'] = 'ASC';
            session_destroy();
        }

        $db = AccesoDatos::getModelo();
        
        $posini = $_SESSION['posini'];

        
        if (isset($_GET['ordenar'])){
            $ordenar = $_GET['ordenar'];
            switch ($_GET['ordenar']){
                case "id"           : $db->ordenar($ordenar,$s_orden,$posini,FPAG); break;
                case "first_name"   : $db->ordenar($ordenar,$s_orden,$posini,FPAG); break;
                case "email"        : $db->ordenar($ordenar,$s_orden,$posini,FPAG); break;
                case "gender"       : $db->ordenar($ordenar,$s_orden,$posini,FPAG); break;
                case "ip_address"   : $db->ordenar($ordenar,$s_orden,$posini,FPAG); break;
                case "telefono"     : $db->ordenar($ordenar,$s_orden,$posini,FPAG); break;
            }
        }
    

    //LLamada a bandera
/*     $db = AccesoDatos::getModelo();
    $band = $db->getFlag();
    $bandera = strtolower($band); */




    //Imprimir cliente
    if ( isset($_GET['imprimirPDF']) && isset($_GET['id']) ) {
        $db->pdfCliente($_GET['id']);
    }


    // Proceso de ordenes de CRUD clientes
    if ( isset($_GET['orden'])){
        switch ($_GET['orden']) {
            case "Nuevo"    : crudAlta(); break;
            case "Borrar"   : crudBorrar   ($_GET['id']); break;
            case "Modificar": crudModificar($_GET['id']); break;
            case "Detalles" : crudDetalles ($_GET['id']); break;
            case "Terminar" : crudTerminar(); break;
        }
    }
} 
// POST Formulario de alta o de modificación
else {
    if (  isset($_POST['orden'])){
         switch($_POST['orden']) {
             case "Nuevo"    : crudPostAlta(); break;
             case "Modificar": crudPostModificar(); break;
             case "Detalles":; // No hago nada
         }
    }
}

/*
 if($_SESSION['datos'] !== null && isset($_GET['ordenar'])){
    
    $tvalores = $_SESSION['datos'];
    
}else{
    
    $db = AccesoDatos::getModelo();
    $posini = $_SESSION['posini'];

    $tvalores = $db->getClientes($posini,FPAG);

}

require_once "app/views/list.php"; */

// Si no hay nada en la buffer 
// Cargo genero la vista con la lista por defecto
if ( ob_get_length() == 0){

    $db = AccesoDatos::getModelo();
    $posini = $_SESSION['posini'];

    if (isset($ordenar) && isset($s_orden)){
        $tvalores = $db->ordenar($ordenar,$s_orden,$posini,FPAG);
    }else{
        $tvalores = $db->getClientes($posini,FPAG);
    }

    require_once "app/views/list.php";    
    
}

$contenido = ob_get_clean();

// Muestro la página principal con el contenido generado
require_once "app/views/principal.php";
$db = AccesoDatos::getModelo();
/* 
echo "EJERCICIO 2: ORDENAR";
echo "<br>";
echo $_GET['ordenar'];
echo "<br>";
echo $_SESSION['s_orden'];
echo "<br>";
echo "<br>";echo "<br>"; */


/* echo "EJERCICIO 3: BANDERA EN DETALLES";
echo "<br>";
echo "CODIGO PAIS = ". $bandera;
echo "<br>";echo "<br>"; */


/* echo $db->validarIP();
echo "<br>";
echo $db->validarTelefono();
echo "<br>";
echo $db->validarCorreo();
echo "<br>";
echo $db->robohash(); */