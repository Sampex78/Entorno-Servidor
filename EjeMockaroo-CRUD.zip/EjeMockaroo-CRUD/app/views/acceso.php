<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
</head>
<body>
<br>
<form method="POST" action="index.php">
    <center>
    <table>
        <tr><th>Login:</th><td><input type="text" name="user"/></td></tr>
        <tr><th>Password:</th><td><input type="text" name="pass"/></td></tr>
        <tr><th colspan=2><input type="submit" name="enviar" value="Iniciar Sesión" ></th></tr>
    </table>
    </center>
</form>
</body>
</html>