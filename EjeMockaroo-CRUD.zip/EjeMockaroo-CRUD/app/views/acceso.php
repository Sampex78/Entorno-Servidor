<?php
session_start();
if(isset($_SESSION['login'])){
    header('Location: index.php');
}

if(isset($_SESSION['contador'])){
    $_SESSION['contador']++;
    if ($_SESSION['contador'] === 3){
        echo "Acceso bloqueado: Inicie sesión desde ventana privada";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
</head>
<body>
<br>
<form method="POST" action="index.php">
    <center>
    <table>
        <tr><th>Login:</th><td><input type="text" name="user"/></td></tr>
        <tr><th>Password:</th><td><input type="text" name="pass"/></td></tr>
        <tr><th colspan=2><input type="submit" value="Iniciar Sesión"></th></tr>
    </table>
    </center>
</form>
</body>
</html>

