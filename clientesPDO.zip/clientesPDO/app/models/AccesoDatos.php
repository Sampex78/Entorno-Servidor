<?php

/*
 * Acceso a datos con BD Usuarios : 
 * Usando la librería mysqli
 * Uso el Patrón Singleton :Un único objeto para la clase
 * Constructor privado, y métodos estáticos 
 */
class AccesoDatos {
    
    private static $modelo = null;
    private $dbh = null;
    
    public static function getModelo(){
        if (self::$modelo == null){
            self::$modelo = new AccesoDatos();
        }
        return self::$modelo;
    }

   // Constructor privado  Patron singleton
    public function __construct(){

        try {
            $dsn = "mysql:host=".DB_SERVER.";dbname=".DATABASE.";charset=utf8";
            $dbh = new PDO($dsn, DB_USER, DB_PASSWD);
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e){
            echo "Error de conexión ".$e->getMessage();
            exit();
        }
    }

    // Cierro la conexión anulando todos los objectos relacioanado con la conexión PDO (stmt)
    public static function closeModelo(){
        if (self::$modelo != null){
            $obj = self::$modelo;
            // Cierro la base de datos
            $obj->dbh = null;
            self::$modelo = null; // Borro el objeto.
        }
    }

    // Devuelvo cuantos filas tiene la tabla
    public function numClientes ():int {
        $stmt = $dbh->prepare("SELECT * FROM Clientes");
        $stmt->execute();
        echo $stmt->rowCount();
    } 
    

    // SELECT Devuelvo la lista de Usuarios
    public function getClientes ($primero,$cuantos):array {
        $stmt = $dbh->prepare("select * from Clientes limit :primero, :cuantos");
        $stmt->bind_param(":primero",$primero);
        $stmt->bind_param(":cuantos",$cuantos);
        $stmt->execute();
        $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach($clientes as $cliente){
            echo $cliente['id'], $cliente['first_name'], $cliente['last_name'], $cliente['email'], $cliente['gender'], $cliente['ip_address'], $cliente['telefono']."<br>";
        }
    }
      
    // SELECT Devuelvo un usuario o false
    public function getCliente (int $id) {
        $stmt = $this->dbh->prepare("select * from Clientes where id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        if ($cliente = $stmt->fetch(PDO::FETCH_ASSOC)){
            echo $cliente['id'], $cliente['first_name'], $cliente['last_name'], $cliente['email'], $cliente['gender'], $cliente['ip_address'], $cliente['telefono']."<br>";
        }
    }
     
    public function getClienteSiguiente($id){

        $cli = false;
        
        $stmt_cliente   = $this->dbh->prepare("select * from Clientes where id >? limit 1");
        if ( $stmt_cliente == false) die ($this->dbh->error);

        // Enlazo $login con el primer ? 
        $stmt_cliente->bind_param("i",$id);
        $stmt_cliente->execute();
        $result = $stmt_cliente->get_result();
        if ( $result ){
            $cli = $result->fetch_object('Cliente');
            }
        
        return $cli;

    }

    public function getClienteAnterior($id){

        $cli = false;
        
        $stmt_cliente   = $this->dbh->prepare("select * from Clientes where id <? order by id DESC limit 1");
        if ( $stmt_cliente == false) die ($this->dbh->error);

        // Enlazo $login con el primer ? 
        $stmt_cliente->bind_param("i",$id);
        $stmt_cliente->execute();
        $result = $stmt_cliente->get_result();
        if ( $result ){
            $cli = $result->fetch_object('Cliente');
            }
        
        return $cli;

    }

    // UPDATE TODO
    public function modCliente($cli):bool{
      
        $stmt   = $this->dbh->prepare("UPDATE Clientes SET first_name=?,last_name=?,email=?,gender=?, ip_address=?,telefono=? WHERE id=?");
        if ( $stmt == false) die ($this->dbh->error);

        $stmt->bind_param("ssssssi",$cli->first_name,$cli->last_name,$cli->email,
                    $cli->gender,$cli->ip_address,$cli->telefono,$cli->id);
        $stmt->execute();
        $resu = ($this->dbh->affected_rows  == 1);
        return $resu;
    }

  
    //INSERT 
    public function addCliente($cli):bool{
       
        // El id se define automáticamente por autoincremento.
        $stmt_creauser  = $this->dbh->prepare(
            "INSERT INTO Clientes(first_name,last_name,email,gender,ip_address,telefono) VALUES(?,?,?,?,?,?)");
        if ( $stmt_creauser == false) die ($this->dbh->error);

        $stmt_creauser->bind_param("ssssss",$cli->first_name,$cli->last_name,$cli->email,
        $cli->gender,$cli->ip_address,$cli->telefono);
        $stmt_creauser->execute();
        $resu = ($this->dbh->affected_rows  == 1);
        return $resu;
    }

   
    //DELETE 
    public function borrarCliente(int $id):bool {
        $stmt_boruser   = $this->dbh->prepare("delete from Clientes where id =?");
        if ( $stmt_boruser == false) die ($this->dbh->error);
       
        $stmt_boruser->bind_param("i", $id);
        $stmt_boruser->execute();
        $resu = ($this->dbh->affected_rows  == 1);
        return $resu;
    }   
    
    
     // Evito que se pueda clonar el objeto. (SINGLETON)
    public function __clone()
    { 
        trigger_error('La clonación no permitida', E_USER_ERROR); 
    }
    
}